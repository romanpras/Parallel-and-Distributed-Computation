/*
 ============================================================================
 Name        : FinalProject.c
 Author      : Roman Prasolov id- 313091746
 ============================================================================
 */
 

#ifndef MUTANT_H
#define MUTANT_H
#pragma once 

double* mutantSequences(char str1[], char str2[], int startOffset, int endOffset, double* weight);

#endif
